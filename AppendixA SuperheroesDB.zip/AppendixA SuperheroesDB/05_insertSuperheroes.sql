GO
USE SuperheroesDb

INSERT INTO Superhero(hero_name,alias,origin) VALUES ('Anthony Stark','IronMan','USA')
INSERT INTO Superhero(hero_name,alias,origin) VALUES ('Steve Rogers','Captain America','USA')
INSERT INTO Superhero(hero_name,alias,origin) VALUES ('Bruce Wayne', 'Batman','USA')

