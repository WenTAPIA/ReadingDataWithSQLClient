GO
USE SuperheroesDb

CREATE TABLE Superhero_Power(
 hero_id int,
 Power_id int,
 CONSTRAINT super_power PRIMARY KEY (hero_id, Power_id)
);

ALTER TABLE Superhero_Power
ADD CONSTRAINT fk_hero_Superhero_Power 
FOREIGN KEY (hero_id) REFERENCES Superhero (id)

ALTER TABLE Superhero_Power
ADD CONSTRAINT fk_power_Superhero_Power 
FOREIGN KEY (Power_id) REFERENCES Power_ (id)