go
use SuperheroesDb

INSERT INTO Assistant (assistant_name, Superhero_id) VALUES ('Jarvis',1)
INSERT INTO Assistant (assistant_name, Superhero_id) VALUES ('Alfred',3)
INSERT INTO Assistant (assistant_name, Superhero_id) VALUES ('Falcon',1)

