go
use SuperheroesDb

INSERT INTO Power_ (power_name,power_description) VALUES ('SuperHuman Strenght','extraordinary Strenght to combat ' )
INSERT INTO Power_ (power_name,power_description) VALUES ('Resistance','It is the time they can fight' )
INSERT INTO Power_ (power_name,power_description) VALUES ('Speed',' Velocity in combat' )
INSERT INTO Power_ (power_name,power_description) VALUES ('Intelligence','Survive capacity ' )

INSERT INTO [SuperheroesDb].[dbo].[Superhero_Power] (hero_id, Power_id) VALUES (1,3)
INSERT INTO [SuperheroesDb].[dbo].[Superhero_Power] (hero_id, Power_id) VALUES (1,4)
INSERT INTO [SuperheroesDb].[dbo].[Superhero_Power] (hero_id, Power_id) VALUES (1,2)
INSERT INTO [SuperheroesDb].[dbo].[Superhero_Power] (hero_id, Power_id) VALUES (2,1)
INSERT INTO [SuperheroesDb].[dbo].[Superhero_Power] (hero_id, Power_id) VALUES (2,3)
INSERT INTO [SuperheroesDb].[dbo].[Superhero_Power] (hero_id, Power_id) VALUES (2,4)
INSERT INTO [SuperheroesDb].[dbo].[Superhero_Power] (hero_id, Power_id) VALUES (3,3)
INSERT INTO [SuperheroesDb].[dbo].[Superhero_Power] (hero_id, Power_id) VALUES (3,4)

SELECT SH.id , SH.alias , P.power_name
FROM Superhero as SH
Inner join [SuperheroesDb].[dbo].[Superhero_Power] as SP ON SP.hero_id=SH.id
inner join Power_ as P ON p.id = SP.Power_id