GO
USE SuperheroesDb

CREATE TABLE Superhero (
	id int PRIMARY KEY IDENTITY(1,1),
	hero_name nvarchar(50) not null,
	alias nvarchar(30) not null,
	origin nvarchar (30) not null
	);

CREATE TABLE Power_ (
	id int PRIMARY KEY IDENTITY(1,1),
	power_name nvarchar(50) not null,
	power_description nvarchar(50) not null
);

CREATE TABLE Assistant (
	id int PRIMARY KEY IDENTITY(1,1),
	assistant_name nvarchar(50) not null
	
);

