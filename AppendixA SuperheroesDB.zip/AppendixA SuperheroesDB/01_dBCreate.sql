CREATE DATABASE SuperheroesDb;
