GO
USE SuperheroesDb

ALTER TABLE Assistant
ADD Superhero_id int not null

ALTER TABLE Assistant
ADD CONSTRAINT fk_Superhero
FOREIGN KEY (Superhero_id) REFERENCES Superhero (id)