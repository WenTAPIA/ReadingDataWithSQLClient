GO
USE SuperheroesDb

DELETE FROM Assistant WHERE assistant_name= 'Falcon' 