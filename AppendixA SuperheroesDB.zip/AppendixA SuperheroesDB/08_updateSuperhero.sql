GO
USE SuperheroesDb

SELECT * FROM Superhero

UPDATE Superhero
SET hero_name = 'Tony Stark'
Where hero_name = 'Anthony Stark'